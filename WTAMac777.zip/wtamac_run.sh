xattr -dr com.apple.quarantine WTAMac.app1
